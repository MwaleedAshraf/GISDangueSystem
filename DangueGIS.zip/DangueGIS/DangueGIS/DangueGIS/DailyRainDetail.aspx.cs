﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class DailyRainDetail : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void GridDailyRain_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "GetsStatus")
            {
                Session["T_DailyRainID"] = e.CommandArgument;
                Response.Redirect("DailyRain");

            }
            else if (e.CommandName == "DeleteStatus")
            {
                Session["T_DailyRainID"] = e.CommandArgument;
                DeleteTemperature(Convert.ToInt32(Session["T_DailyRainID"]));
                GridDailyRain.DataBind();
            }
        }
        //Delete Experience

        public string DeleteTemperature(int T_DailyRainID)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteDailyRain";
            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = T_DailyRainID;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }

        protected void GridDailyRain_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}