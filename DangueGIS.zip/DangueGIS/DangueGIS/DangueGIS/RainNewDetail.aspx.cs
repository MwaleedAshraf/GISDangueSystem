﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class RainNewDetail : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void GridNewRain_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "GetsStatus")
            {
                Session["T_RainID"] = e.CommandArgument;
                Response.Redirect("RainNew");

            }
            else if (e.CommandName == "DeleteStatus")
            {
                Session["T_RainID"] = e.CommandArgument;
                DeleteTemperature(Convert.ToInt32(Session["T_RainID"]));
                GridNewRain.DataBind();
            }
        }
        //Delete Experience

        public string DeleteTemperature(int T_RainID)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteNewRain";
            cmd.Parameters.Add("@RainId", SqlDbType.Int).Value = T_RainID;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }

        protected void GridNewRain_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}