﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class TemperatureNew : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindCity();
                Convert.ToInt32(Session["T_TempId"]);
                ViewNewTemperature(Convert.ToInt32(Session["T_TempId"]));
            }
        }
        public void BindCity()
        {
            DataSet ds = new DataSet();
            ds = GetCity();

            drpCity.DataTextField = "City";
            drpCity.DataSource = ds;
            drpCity.DataBind();

        }

        public DataSet GetCity()
        {

            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            DataSet ds = new DataSet();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct city from tblDailyRain order by city ";
            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            conn.Close();
            return ds;

        }
        public void ViewNewTemperature(int T_TempId)
        {
            try
            {
                conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
                SqlCommand cmd;
                string str;
                conn.Open();
                str = "select * from tbl_NewTemperature where TempId='" + T_TempId + "'";
                cmd = new SqlCommand(str, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    drpCity.Value = reader["CityName"].ToString();
                    drpYear.Value = reader["Year"].ToString();
                    drpDay.Value = reader["Day"].ToString();
                    drpMonth.Value = reader["Month"].ToString();
                    txtmintemp.Value = reader["MinTemp"].ToString();
                    txtmaxtemp.Value = reader["MaxTemp"].ToString();
                    txtAvgtemp.Value = reader["AverageTemp"].ToString();


                    conn.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }
        }
        //Add New Rain
        public string AddNewTemperature(string CityName, int Year, int Day, string Month, decimal MinTemp, decimal MaxTemp, decimal AverageTemp)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "AddNewTemperature";
            cmd.Parameters.Add("@CityName", SqlDbType.VarChar).Value = CityName;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year;
            cmd.Parameters.Add("@Day", SqlDbType.Int).Value = Day;
            cmd.Parameters.Add("@Month", SqlDbType.VarChar).Value = Month;
            cmd.Parameters.Add("@MinTemp", SqlDbType.Decimal).Value = MinTemp;
            cmd.Parameters.Add("@MaxTemp", SqlDbType.Decimal).Value = MaxTemp;
            cmd.Parameters.Add("@AverageTemp", SqlDbType.Decimal).Value = AverageTemp;

            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btn_save_Click(object sender, EventArgs e)
        {

            string res = AddNewTemperature(drpCity.Value, int.Parse(drpYear.Value), int.Parse(drpDay.Value), drpMonth.Value, decimal.Parse(txtmintemp.Value), decimal.Parse(txtmaxtemp.Value), decimal.Parse(txtAvgtemp.Value));
            lblMessage.Text = "Record Successfully Inserted";
        }
        public string UpdateNewTemperature(int TempId,string CityName, int Year, int Day, string Month, decimal MinTemp, decimal MaxTemp, decimal AverageTemp)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "UpdateNewTemperature";
            cmd.Parameters.Add("@TempId", SqlDbType.VarChar).Value = TempId;
            cmd.Parameters.Add("@CityName", SqlDbType.VarChar).Value = CityName;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year;
            cmd.Parameters.Add("@Day", SqlDbType.Int).Value = Day;
            cmd.Parameters.Add("@Month", SqlDbType.VarChar).Value = Month;
            cmd.Parameters.Add("@MinTemp", SqlDbType.Float).Value = MinTemp;
            cmd.Parameters.Add("@MaxTemp", SqlDbType.Float).Value = MaxTemp;
            cmd.Parameters.Add("@AverageTemp", SqlDbType.Float).Value = AverageTemp;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            string res = UpdateNewTemperature(Convert.ToInt32(Session["T_TempId"]), drpCity.Value, int.Parse(drpYear.Value), int.Parse(drpDay.Value), drpMonth.Value, decimal.Parse(txtmintemp.Value), decimal.Parse(txtmaxtemp.Value), decimal.Parse(txtAvgtemp.Value)).ToString();
            lblMessage.Text = "Record Successfully Updated";
            Response.Redirect("TemperatureNewDetail");
        }

        //Delete Dayoff Method

        protected void btnDetail_Click(object sender, EventArgs e)
        {
            Response.Redirect("TemperatureNewDetail");
        }
    }
}