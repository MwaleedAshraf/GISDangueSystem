﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DistBLL
/// </summary>
public class DistBLL
{
    private int _DistrictId;

    public int DistrictId
    {
        get { return _DistrictId; }
        set { _DistrictId = value; }
    }

    private int _DistName;

    public int DistName
    {
        get { return _DistName; }
        set { _DistName = value; }
    }

    private int _ProvinceId;

    public int ProvinceId
    {
        get { return _ProvinceId; }
        set { _ProvinceId = value; }
    }

}