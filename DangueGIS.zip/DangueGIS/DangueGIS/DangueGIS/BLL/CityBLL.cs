﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CityBLL
/// </summary>
public class CityBLL
{
	public CityBLL()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}