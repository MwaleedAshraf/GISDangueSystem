﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for PatientBLL
/// </summary>
public class PatientBLL
{
    private string _regDate;

    public string RegDate
    {
        get { return _regDate; }
        set { _regDate = value; }
    }

    private string _week;

    public string week
    {
        get { return _week; }
        set { _week = value; }
    }

    private string _sex;

    public string SEX
    {
        get { return _sex; }
        set { _sex = value; }
    }

    private int _age;

    public int Age
    {
        get { return _age; }
        set { _age = value; }
    }

    private int _cityId;

    public int CityId
    {
        get { return _cityId; }
        set { _cityId = value; }
    }

    private string _status;

    public string Status
    {
        get { return _status; }
        set { _status = value; }
    }

    private string _labResultIGM;

    public string LabResultIGM
    {
        get { return _labResultIGM; }
        set { _labResultIGM = value; }
    }

    private string _labResultIGG;

    public string LabResultIGG
    {
        get { return _labResultIGG; }
        set { _labResultIGG = value; }
    }
}