﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class WeeklyTemperatureDetail : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void GridWeeklyTemp_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "GetsStatus")
            {
                Session["H_WeeklyTempID"] = e.CommandArgument;
                Response.Redirect("WeeklyTemperature");

            }
            else if (e.CommandName == "DeleteStatus")
            {
                Session["H_WeeklyTempID"] = e.CommandArgument;
                DeleteWeeklyTemp(Convert.ToInt32(Session["H_WeeklyTempID"]));
                GridWeeklyTemp.DataBind();
            }
        }
        //Delete Experience

        public string DeleteWeeklyTemp(int H_WeeklyTempID)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteWeeklyTemperature";
            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = H_WeeklyTempID;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }

        protected void GridWeeklyTemp_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}