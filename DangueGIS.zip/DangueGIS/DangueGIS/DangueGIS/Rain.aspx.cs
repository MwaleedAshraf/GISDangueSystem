﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class Rain : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindCity();
                Convert.ToInt32(Session["R_RainID"]);
                ViewRain(Convert.ToInt32(Session["R_RainID"]));
            }
        }
        public void ViewRain(int R_RainID)
        {
            try
            {
                conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
                SqlCommand cmd;
                string str;
                conn.Open();
                str = "select * from tbl_Rain where RainID='" + R_RainID + "'";
                cmd = new SqlCommand(str, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    drpCity.Value = reader["CityId"].ToString();
                    drpMonth.Value = reader["Month"].ToString();
                    drpweeknum.Value = reader["WeekNo"].ToString();
                    txtAvgRain.Value = reader["AvgRainValue"].ToString();
                    drpDay.Value = reader["Day"].ToString();
                    drpyear.Value = reader["Year"].ToString();

                    conn.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }
        }
        
        public void BindCity()
        {
            DataSet ds = new DataSet();
            ds = GetCity();
            drpCity.DataValueField = "CityId";
            drpCity.DataTextField = "CityName";
            drpCity.DataSource = ds;
            drpCity.DataBind();

        }

        public DataSet GetCity()
        {

            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            DataSet ds = new DataSet();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select CityId, CityName  From tblCity";
            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            conn.Close();
            return ds;

        }

        public string AddRain(int CityId, int Month, int WeekNo, float AvgRainValue, int Day, int Year)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "AddRain ";
            cmd.Parameters.Add("@CityId", SqlDbType.Int).Value = CityId;
            cmd.Parameters.Add("@Month", SqlDbType.Int).Value = Month;
            cmd.Parameters.Add("@WeekNo", SqlDbType.Int).Value = WeekNo;
            cmd.Parameters.Add("@AvgRainValue", SqlDbType.Float).Value = AvgRainValue;
            cmd.Parameters.Add("@Day", SqlDbType.Int).Value = Day;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year;

            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btn_save_Click(object sender, EventArgs e)
        {

            string res = AddRain(int.Parse(drpCity.Value), int.Parse(drpMonth.Value), int.Parse(drpweeknum.Value),  float.Parse(txtAvgRain.Value), int.Parse(drpDay.Value), int.Parse(drpyear.Value));
            lblMessage.Text = "Record Successfully Inserted";
        }

        // Update Dayoff Method
        public string UpdateRain(int RainID, int CityId, int Month, int WeekNo, float AvgRainValue, int Day, int Year)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "UpdateRain";
            cmd.Parameters.Add("@RainID", SqlDbType.Int).Value = RainID;
            cmd.Parameters.Add("@CityId", SqlDbType.Int).Value = CityId;
            cmd.Parameters.Add("@Month", SqlDbType.Int).Value = Month;
            cmd.Parameters.Add("@WeekNo", SqlDbType.Int).Value = WeekNo;
            cmd.Parameters.Add("@AvgRainValue", SqlDbType.Float).Value = AvgRainValue;
            cmd.Parameters.Add("@Day", SqlDbType.Int).Value = Day;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            string res = UpdateRain(Convert.ToInt32(Session["R_RainID"]), int.Parse(drpCity.Value), int.Parse(drpMonth.Value), int.Parse(drpweeknum.Value), float.Parse(txtAvgRain.Value), int.Parse(drpDay.Value), int.Parse(drpyear.Value)).ToString();
            lblMessage.Text = "Record Successfully Updated";
            Response.Redirect("RainDetail");
        }

        //Delete Dayoff Method

        protected void btnDetail_Click(object sender, EventArgs e)
        {
            Response.Redirect("RainDetail");
        }
    }
}