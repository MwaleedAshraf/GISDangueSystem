﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class TemperatureNewDetail : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void GridNewTemperature_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "GetsStatus")
            {
                Session["T_TempId"] = e.CommandArgument;
                Response.Redirect("TemperatureNew");

            }
            else if (e.CommandName == "DeleteStatus")
            {
                Session["T_TempId"] = e.CommandArgument;
                DeleteTemperature(Convert.ToInt32(Session["T_TempId"]));
                GridNewTemperature.DataBind();
            }
        }
        //Delete Experience

        public string DeleteTemperature(int T_TempId)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteNewTemperature";
            cmd.Parameters.Add("@T_TempId", SqlDbType.Int).Value = T_TempId;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }

        protected void GridNewTemperature_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}