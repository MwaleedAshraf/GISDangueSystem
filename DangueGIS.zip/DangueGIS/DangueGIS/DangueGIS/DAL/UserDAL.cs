﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for UserDAL
/// </summary>
public class UserDAL
{
    SqlConnection con = new SqlConnection(DALHelper.ConnectionString);
    public UserBLL logon(UserBLL lgn)
    {
        string sbk = "select username,password from tblUsers where UserName='" + lgn.UserName + "'";
        SqlCommand cmd = new SqlCommand(sbk, con);
        SqlDataAdapter adb = new SqlDataAdapter(cmd);
        DataSet dst;
        UserBLL ub = new UserBLL();
        try
        {
            con.Open();
            dst = new DataSet();
            adb.Fill(dst, "Table");
            ub.UserName = dst.Tables[0].Rows[0].ItemArray[0].ToString();
            ub.Password = dst.Tables[0].Rows[0].ItemArray[1].ToString();
        }
        catch //(Exception ex)
        {
            //throw ex;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                
                con.Close();

            }
            
        }
        return ub;
    }
    public string GetUserType(UserBLL lgn)
    {
        SqlCommand cmd = new SqlCommand("select Type from tblUsers where UserName='" + lgn.UserName + "' and Password='" + lgn.Password + "'", con);
        SqlDataAdapter adb = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        string type = "";
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            adb.Fill(ds, "table");
            type = ds.Tables["table"].Rows[0][0].ToString();
        }
        catch
        {


        }
        finally
        {
            if (con.State == ConnectionState.Open) con.Close();
        }
        //if (ds != null) ds.TrimExcess();
        return type;
    }
    public string GetUserType(string lgn)
    {
        SqlCommand cmd = new SqlCommand("select Type from tblUsers where UserName='" + lgn + "'", con);
        SqlDataAdapter adb = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        string type = "";
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            adb.Fill(ds, "table");
            type = ds.Tables["table"].Rows[0][0].ToString();
        }
        catch
        {


        }
        finally
        {
            if (con.State == ConnectionState.Open) con.Close();
        }
        //if (ds != null) ds.TrimExcess();
        return type;
    }
    public void SaveUser(UserBLL ur)
    {
        SqlCommand cmd = new SqlCommand("usp_InserttblUser", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@UserName", ur.UserName));
        cmd.Parameters.Add(new SqlParameter("@Password", ur.Password));
        cmd.Parameters.Add(new SqlParameter("@Type", ur.Type));
        cmd.Parameters.Add(new SqlParameter("@TransDate", ur.TransDate));
        cmd.Parameters.Add(new SqlParameter("@Status", ur.Status));
        cmd.Parameters.Add(new SqlParameter("@UserID", ur.UserID));
        try
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            cmd.ExecuteNonQuery();
        }
        catch
        {
        }
        finally
        {
            if (con.State == ConnectionState.Open)
                con.Close();
        }
    }
    public bool passexist(string userid, string passid)
    {
        string query = @"select Password from tblusers where Password='"+passid+"' and Username='"+userid+"'";
        SqlCommand cmd = new SqlCommand(query, con);
        SqlDataReader dr;
        bool flag = false;
        try
        {
            con.Open();
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                flag = true;
            }
            else
            { flag = false; }


        }
        catch (Exception ex)
        { throw ex; }
        finally
        {
            con.Close();
        }
        return flag;
    }
    public void updateuser(UserBLL ub)
    {
        SqlCommand cmd = new SqlCommand("update tblusers set Password='"+ub.Password+"' where Username='"+ub.UserName+"'", con);
        
        try
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            cmd.ExecuteNonQuery();
        }
        catch
        {
        }
        finally
        {
            if (con.State == ConnectionState.Open)
                con.Close();
        }
    }
}