﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DALHelper
/// </summary>
public class DALHelper
{
    public static string ConnectionString = "Data Source=OFFICE-PC;Initial Catalog=GISDengue;Integrated Security=True";
}