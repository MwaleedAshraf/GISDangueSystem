﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace ShahbazGIS
{
    public partial class Humidity : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindCity();
                Convert.ToInt32(Session["H_HumidityID"]);
                ViewHumidity(Convert.ToInt32(Session["H_HumidityID"]));
            }
        }
        public void ViewHumidity(int H_HumidityID)
        {
            try
            {
                conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
                SqlCommand cmd;
                string str;
                conn.Open();
                str = "select * from tbl_Humidity where HumidityID='" + H_HumidityID + "'";
                cmd = new SqlCommand(str, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    drpCity.Value = reader["CityId"].ToString();
                    drpMonth.Value = reader["Month"].ToString();
                    drpweeknum.Value = reader["WeekNo"].ToString();
                    txtAvgHumidity.Value = reader["AvgHumidityValue"].ToString();
                    txtMinHumidity.Value = reader["MinHumidity"].ToString();
                    txtMaxHumidity.Value = reader["MaxHumidity"].ToString();
                    drpDay.Value = reader["Day"].ToString();
                    drpyear.Value = reader["Year"].ToString();

                    conn.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }
        }
        //public string DeleteDayOff(int D_OffID)
        //{
        //    conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["FaisalHRConnectionString"].ToString();
        //    conn.Open();
        //    cmd.Connection = conn;
        //    cmd.Parameters.Clear();
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.CommandText = "DeleteDayOff";
        //    cmd.Parameters.Add("@DayOff_ID", SqlDbType.Int).Value = D_OffID;

        //    int i = cmd.ExecuteNonQuery();


        //    conn.Close();
        //    if (i > 0)
        //    {
        //        return "Success";
        //    }
        //    else { return "Fail"; }


        //}
        //public void ViewDayOff(int DayOff_ID)
        //{
        //    try
        //    {
        //        conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["FaisalHRConnectionString"].ToString();
        //        SqlCommand cmd;
        //        string str;
        //        conn.Open();
        //        str = "select * from tblDayOff where DayOff_ID='" + DayOff_ID + "'";
        //        cmd = new SqlCommand(str, conn);
        //        SqlDataReader reader = cmd.ExecuteReader();
        //        if (reader.Read())
        //        {
        //            txtDayOffMonthdate.Value = reader["DayOffMonth"].ToString();
        //            txtDayOff.Value = reader["DayOff"].ToString();
        //            drpEmployee.Value = reader["Emp_ID"].ToString();
        //            conn.Close();
        //        }
        //        conn.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        string message = ex.Message;
        //    }
        //}
        public void BindCity()
        {
            DataSet ds = new DataSet();
            ds = GetCity();
            drpCity.DataValueField = "city";
            drpCity.DataTextField = "city";
            drpCity.DataSource = ds;
            drpCity.DataBind();

        }

        public DataSet GetCity()
        {

            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            DataSet ds = new DataSet();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct city from tblHumidityMorning order by city ";
            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            conn.Close();
            return ds;

        }

        public string AddHumidity(int CityId , int Month, int WeekNo, float AvgHumidityValue, float MinHumidity, float MaxHumidity, int Day, int Year)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "AddHumidity ";
            cmd.Parameters.Add("@CityId", SqlDbType.Int).Value = CityId;
            cmd.Parameters.Add("@Month", SqlDbType.Int).Value = Month;
            cmd.Parameters.Add("@WeekNo", SqlDbType.Int).Value = WeekNo;
            cmd.Parameters.Add("@AvgHumidityValue", SqlDbType.Float).Value = AvgHumidityValue;
            cmd.Parameters.Add("@MinHumidity", SqlDbType.Float).Value = MinHumidity;
            cmd.Parameters.Add("@MaxHumidity", SqlDbType.Float).Value = MaxHumidity;
            cmd.Parameters.Add("@Day", SqlDbType.Int).Value = Day;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year; 

            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btn_save_Click(object sender, EventArgs e)
        {

            string res = AddHumidity(int.Parse(drpCity.Value), int.Parse(drpMonth.Value), int.Parse(drpweeknum.Value),float.Parse(txtAvgHumidity.Value),float.Parse(txtMinHumidity.Value),float.Parse(txtMaxHumidity.Value), int.Parse(drpDay.Value), int.Parse(drpyear.Value));
            lblMessage.Text = "Record Successfully Inserted";
        }

        // Update Dayoff Method
        public string UpdateHumidity(int HumidityID, int CityId, int Month, int WeekNo, float AvgHumidityValue, float MinHumidity, float MaxHumidity, int Day, int Year)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "UpdateHumidity";
            cmd.Parameters.Add("@HumidityID", SqlDbType.Int).Value = HumidityID;
            cmd.Parameters.Add("@CityId", SqlDbType.Int).Value = CityId;
            cmd.Parameters.Add("@Month", SqlDbType.Int).Value = Month;
            cmd.Parameters.Add("@WeekNo", SqlDbType.Int).Value = WeekNo;
            cmd.Parameters.Add("@AvgHumidityValue", SqlDbType.Float).Value = AvgHumidityValue;
            cmd.Parameters.Add("@MinHumidity", SqlDbType.Float).Value = MinHumidity;
            cmd.Parameters.Add("@MaxHumidity", SqlDbType.Float).Value = MaxHumidity;
            cmd.Parameters.Add("@Day", SqlDbType.Int).Value = Day;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            string res = UpdateHumidity(Convert.ToInt32(Session["H_HumidityID"]), int.Parse(drpCity.Value), int.Parse(drpMonth.Value), int.Parse(drpweeknum.Value), float.Parse(txtAvgHumidity.Value), float.Parse(txtMinHumidity.Value), float.Parse(txtMaxHumidity.Value), int.Parse(drpDay.Value), int.Parse(drpyear.Value)).ToString();
            lblMessage.Text = "Record Successfully Updated";
            Response.Redirect("HumidityDetail");
        }

        //Delete Dayoff Method

        protected void btnDetail_Click(object sender, EventArgs e)
        {
            Response.Redirect("HumidityDetail");
        }
    }
}