﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class RegistrationDetail : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        protected void GridRegistration_Rowcommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "GetsStatus")
            {
                Session["T_RegID"] = e.CommandArgument;
                Response.Redirect("Registration");

            }
            else if (e.CommandName == "DeleteStatus")
            {
                Session["T_RegID"] = e.CommandArgument;
                DeleteRegistration(Convert.ToInt32(Session["T_RegID"]));

            }
        }
        public string DeleteRegistration(int T_RegID)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteRegistration";
            cmd.Parameters.Add("@RegNo", SqlDbType.Int).Value = T_RegID;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void GridRegistration_SelectedIndexChanged(object sender,EventArgs e)
        {
            
        }
    }
}