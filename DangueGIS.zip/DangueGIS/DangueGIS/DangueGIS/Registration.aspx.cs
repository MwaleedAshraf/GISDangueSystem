﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class Registration : System.Web.UI.Page
    {

        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Convert.ToInt32(Session["T_RegID"]);
                ViewTemperature(Convert.ToInt32(Session["T_RegID"]));
            }
        }
        public void ViewTemperature(int T_RegID)
        {
            try
            {
                conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
                SqlCommand cmd;
                string str;
                conn.Open();
                str = "select * from tblRegistration where RegNo='" + T_RegID + "'";
                cmd = new SqlCommand(str, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtPName.Value = reader["PatientName"].ToString();
                    DateTime dt = new DateTime();
                    dt = DateTime.Parse(reader["RegDate"].ToString());

                    drpRegdate.Value = dt.ToString("dd/MM/yyyy");

                    drpSex.Value = reader["SEX"].ToString();
                    txtPAge.Value = reader["Age"].ToString();
                    drpStatus.Value = reader["Status"].ToString();
                    drplabreslt.Value = reader["LabResultIGM"].ToString();
                    drpIGGreslt.Value = reader["LabResultIGG"].ToString();

                    conn.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }
        }


        public string AddRegistration(string PatientName, DateTime RegDate, string SEX, float Age,int DistId, string Status, string LabResultIGM, string LabResultIGG,string Weeks)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "AddRegistration";
            cmd.Parameters.Add("@PatientName", SqlDbType.VarChar).Value = PatientName;
            cmd.Parameters.Add("@RegDate", SqlDbType.Date).Value = RegDate;
            cmd.Parameters.Add("@SEX", SqlDbType.NVarChar).Value = SEX;
            cmd.Parameters.Add("@Age", SqlDbType.Float).Value = Age;
            cmd.Parameters.Add("@DistId", SqlDbType.Int).Value = DistId;
            cmd.Parameters.Add("@Status", SqlDbType.NVarChar).Value = Status;
            cmd.Parameters.Add("@LabResultIGM", SqlDbType.NVarChar).Value = LabResultIGM;
            cmd.Parameters.Add("@LabResultIGG", SqlDbType.NVarChar).Value = LabResultIGG;
            cmd.Parameters.Add("@Weeks", SqlDbType.VarChar).Value = Weeks;


            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btn_save_Click(object sender, EventArgs e)
        {
            string week = "";
            DateTime dt = new DateTime();
            dt = System.DateTime.Now;
            if (dt.Day <= 7)
            {
                week = "Week 1";

            }
            else if (dt.Day <= 14)
            {
                week = "Week 2";

            }
            else if (dt.Day <= 21)
            {
                week = "Week 3";

            }
            else if (dt.Day <= 31)
            {
                week = "Week 4";

            }
            DateTime DT = new DateTime();
            DT = DateTime.Parse((drpRegdate.Value).ToString());
            DistDAL dDAL = new DistDAL();
            int id = dDAL.GetMaxPCode(Session["username"].ToString());
            string res = AddRegistration(txtPName.Value, DT, drpSex.Value, float.Parse(txtPAge.Value),id ,drpStatus.Value, drplabreslt.Value, drpIGGreslt.Value, week);
            //lblMessage.Text = "Record Successfully Inserted";
        }

        // Update Dayoff Method
        public string UpdateRegistration(int RegNo,string PatientName, DateTime RegDate, string SEX, float Age, int DistId, string Status, string LabResultIGM, string LabResultIGG, string Weeks)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "UpdateRegistration";
            cmd.Parameters.Add("@RegNo", SqlDbType.Int).Value = RegNo;
            cmd.Parameters.Add("@PatientName", SqlDbType.VarChar).Value = PatientName;
            cmd.Parameters.Add("@RegDate", SqlDbType.Date).Value = RegDate;
            cmd.Parameters.Add("@SEX", SqlDbType.NVarChar).Value = SEX;
            cmd.Parameters.Add("@Age", SqlDbType.Float).Value = Age;
            cmd.Parameters.Add("@DistId", SqlDbType.Int).Value = DistId;
            cmd.Parameters.Add("@Status", SqlDbType.NVarChar).Value = Status;
            cmd.Parameters.Add("@LabResultIGM", SqlDbType.NVarChar).Value = LabResultIGM;
            cmd.Parameters.Add("@LabResultIGG", SqlDbType.NVarChar).Value = LabResultIGG;
            cmd.Parameters.Add("@Weeks", SqlDbType.VarChar).Value = Weeks;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            string week = "";
            DateTime dt = new DateTime();
            dt = System.DateTime.Now;
            if (dt.Day <= 7)
            {
                week = "Week 1";

            }
            else if (dt.Day <= 14)
            {
                week = "Week 2";

            }
            else if (dt.Day <= 21)
            {
                week = "Week 3";

            }
            else if (dt.Day <= 31)
            {
                week = "Week 4";

            }
            DistDAL dDAL = new DistDAL();
            int id = dDAL.GetMaxPCode(Session["username"].ToString());

            string res = UpdateRegistration(Convert.ToInt32(Session["T_RegID"]),txtPName.Value, DateTime.Parse(drpRegdate.Value), drpSex.Value, float.Parse(txtPAge.Value), id, drpStatus.Value, drplabreslt.Value, drpIGGreslt.Value, week).ToString();
            //lblMessage.Text = "Record Successfully Updated";
            Response.Redirect("RegistrationDetail");
        }

        //Delete Dayoff Method

        protected void btnDetail_Click(object sender, EventArgs e)
        {
            Response.Redirect("RegistrationDetail");
        }

    }
}