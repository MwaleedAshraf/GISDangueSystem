﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class HumidityEveningDetail : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void GridHumidityEvening_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "GetsStatus")
            {
                Session["T_HumidityEveID"] = e.CommandArgument;
                Response.Redirect("HumidityEvening");

            }
            else if (e.CommandName == "DeleteStatus")
            {
                Session["T_HumidityEveID"] = e.CommandArgument;
                DeleteTemperature(Convert.ToInt32(Session["T_HumidityEveID"]));
                GridHumidityEvening.DataBind();
            }
        }
        //Delete Experience

        public string DeleteTemperature(int T_HumidityEveID)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteEveningHumidity";
            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = T_HumidityEveID;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }

        protected void GridHumidityEvening_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}