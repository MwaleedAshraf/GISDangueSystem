﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.IO;

public partial class RegisterPatient : System.Web.UI.Page
{
    PatientBLL p = new PatientBLL();
    PatientDAL pDAL = new PatientDAL();
    DistDAL dDAL = new DistDAL();
    int id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            id = dDAL.GetMaxPCode(Session["username"].ToString());
            
        }
        catch { }
        lblDistName.Text = Session["username"].ToString();
    }
    protected void txtAge_TextChanged(object sender, EventArgs e)
    {
        double age;
        age = Convert.ToDouble(txtAge.Text);
        if (age< 0 || age> 100)
        {
            lblAge.Text = "You Entered Age not Valid";
            lblAge.Visible = true;
            txtAge.Text = string.Empty;
            txtAge.Focus();
            return;
        }
        
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        
        p.Age = Convert.ToInt32(txtAge.Text);
        p.CityId = id;
        if(rbtIGM.Checked==true)
        {
            p.LabResultIGM=ddlIGM.Text;
        }
        else
        {
            p.LabResultIGM = ddlIGM.Text;
        }
        if (rbtIGG.Checked == true)
        {
            p.LabResultIGG = ddlIGG.Text;
        }
        else
        {
            p.LabResultIGG = ddlIGG.Text;
        }
        p.RegDate = System.DateTime.Now.Date.ToString() ;

        DateTime  dt = new DateTime();
        dt = System.DateTime.Now;
       if ( dt.Day<=7){
       p.week = "Week 1";
       
       }
       else if ( dt.Day<=14){
       p.week = "Week 2";
       
       }
         else if (dt.Day<=21){
       p.week = "Week 3";
       
       }
         else if (dt.Day<=31){
       p.week = "Week 4";
       
       }

        //if(rbtMale.Checked==true)
        //    p.SEX="Male";
        //else
        //    p.SEX="Female";
        //if(rbtCured.Checked==true)
        //    p.Status="Cured";
        //else if(rbtPositive.Checked==true)
        //    p.Status="Positive";
        //else if(rbtResultAwaited.Checked==true)
        //    p.Status="Result Awaited";
        //else
        //    p.Status="Suspected";

        pDAL.SavePatient(p);
        lblMessage.Text="Record Saved Successfully";
        GridView1.DataBind();

    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=gvtocsv.csv");
        Response.Charset = "";
        Response.ContentType = "application/text";
        StringBuilder sBuilder = new System.Text.StringBuilder();
        for (int index = 0; index < GridView1.Columns.Count; index++)
        {
            sBuilder.Append(GridView1.Columns[index].HeaderText + ',');
        }
        sBuilder.Append("\r\n");
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            for (int k = 0; k < GridView1.HeaderRow.Cells.Count; k++)
            {
                sBuilder.Append(GridView1.Rows[i].Cells[k].Text.Replace(",", "") + ",");
            }
            sBuilder.Append("\r\n");
        }
        Response.Output.Write(sBuilder.ToString());
        Response.Flush();
        Response.End();
    }
}