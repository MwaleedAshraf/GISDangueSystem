﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.IO;

public partial class Quarterly : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            lblDistrictName.Text = Session["username"].ToString();
        }
        catch (Exception)
        {

            Response.Redirect("Login");
        }

    }
    SqlConnection con = new SqlConnection(DALHelper.ConnectionString);

    //protected void btnExport_Click(object sender, EventArgs e)
    //{
    //    Response.Clear();
    //    Response.Buffer = true;
    //    Response.AddHeader("content-disposition", "attachment;filename=gvtocsv.csv");
    //    Response.Charset = "";
    //    Response.ContentType = "application/text";
    //    StringBuilder sBuilder = new System.Text.StringBuilder();
    //    for (int index = 0; index < GridView1.Columns.Count; index++)
    //    {
    //        sBuilder.Append(GridView1.Columns[index].HeaderText + ',');
    //    }
    //    sBuilder.Append("\r\n");
    //    for (int i = 0; i < GridView1.Rows.Count; i++)
    //    {
    //        for (int k = 0; k < GridView1.HeaderRow.Cells.Count; k++)
    //        {
    //            sBuilder.Append(GridView1.Rows[i].Cells[k].Text.Replace(",", "") + ",");
    //        }
    //        sBuilder.Append("\r\n");
    //    }
    //    Response.Output.Write(sBuilder.ToString());
    //    Response.Flush();
    //    Response.End();
    //}
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int number;
        lblDistrictName.Text = "District: "+ Session["username"].ToString();
        number = GetDist(ddlYear.Text, Session["username"].ToString());
        lblNoofPatients.Text = "Total Patients: "+ number.ToString();
        int avgTemp = GetTemp(ddlYear.Text,  Session["username"].ToString());
        int avgHum = GetHum(ddlYear.Text,   Session["username"].ToString());
        decimal avgRain = GetRain(ddlYear.Text,  Session["username"].ToString());
        lblTemper.Text = "The Average Weekly Temperature is: " + avgTemp;
        lblHumidity.Text = "The Average Weekly Humidity is: " + avgHum;
        lblRain.Text = "The Average Weekly Rain is: " + avgRain;
        Chart1.DataSource = GraphData(ddlYear.Text,  Session["username"].ToString()).Tables[0];
        Chart1.DataBind();
        if (number > 3 || ((avgTemp > 14 && avgTemp < 36) && (avgHum > 60 && avgHum < 76)))
            {
            lblOutbreak.Text = "The Dengue Out Break Chance is Increasing.";

            }
        else { lblOutbreak.Text = "The Dengue No Out Break Chance."; }
    }
    string month;
    public int GetDist(string ryear,  string rdist)
    {

        string a = "";
        string qury = @"select COUNT(r.RegDate) as number from 
                tblRegistration r
                join tblDist d on d.DistrictId=r.DistId
                where  YEAR(r.RegDate)= " + ryear + " and  d.DistName='" + rdist + "'";
        SqlCommand cmd = new SqlCommand(qury, con);
        cmd.CommandType = CommandType.Text;
        int t = 0;
        try
        {
            con.Open();
            SqlDataReader me = cmd.ExecuteReader(CommandBehavior.SingleRow);
            if (me.Read())
            {
                if (me["number"] == DBNull.Value)
                    t = 0;
                else
                    t = Convert.ToInt32(me["number"]);
            }

            con.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
                con.Close();
        }
        return t;
    }
    public int GetTemp(string ryear,  string rdist)
        {
      
        string a = "";
        string qury = @"select  avg(WeeklyAverageTemperature) as number From  ( SELECT isnull([tbl_NewTemperature].AverageTemp, 0) as WeeklyAverageTemperature FROM [tbl_NewTemperature] WHERE [tbl_NewTemperature].CityName = @City  group by AverageTemp) a";
        SqlCommand cmd = new SqlCommand(qury, con);
        //cmd.Parameters.Add("@Month", SqlDbType.VarChar).Value = rmonth;
        cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = rdist;
      
        cmd.CommandType = CommandType.Text;
        int t = 0;
        try
            {
            con.Open();
            SqlDataReader me = cmd.ExecuteReader(CommandBehavior.SingleRow);
            if (me.Read())
                {
                if (me["number"] == DBNull.Value)
                    t = 0;
                else
                    t = Convert.ToInt32(me["number"]);
                }

            con.Close();
            }
        catch (Exception ex)
            {
            throw ex;
            }
        finally
            {
            if (con.State == ConnectionState.Open)
                con.Close();
            }
        return t;
        }
    public int GetHum(string ryear,  string rdist)
        {
        int week = 0;
       
        string a = "";
        string qury = @" select  avg(AverageWeeklyHumadity) As number From  ( 
	 SELECT isnull([tbl_NewHumidity].AverageHumidity, 0) as AverageWeeklyHumadity 
FROM [tbl_NewHumidity]
     
WHERE  [tbl_NewHumidity].CityName = @City      group by AverageHumidity) a";
        SqlCommand cmd = new SqlCommand(qury, con);
        //cmd.Parameters.Add("@Month", SqlDbType.VarChar).Value = rmonth;
        cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = rdist;
       
        cmd.CommandType = CommandType.Text;
        int t = 0;
        try
            {
            con.Open();
            SqlDataReader me = cmd.ExecuteReader(CommandBehavior.SingleRow);
            if (me.Read())
                {
                if (me["number"] == DBNull.Value)
                    t = 0;
                else
                    t = Convert.ToInt32(me["number"]);
                }

            con.Close();
            }
        catch (Exception ex)
            {
            throw ex;
            }
        finally
            {
            if (con.State == ConnectionState.Open)
                con.Close();
            }
        return t;
        }
    public decimal GetRain(string ryear, string rdist )
        {
            string Month1=""; string Month2=""; string Month3="";
            if (drpQuarter.Text == "First")
            {
            Month1 = "January";
                Month2 = "February";
                Month3 = "March";
            }
            else if (drpQuarter.Text == "Second")
            {
            Month1 = "April";
                Month2 = "May";
                Month3 = "June";
            }
                    else if (drpQuarter.Text == "Third")
            {
            Month1 = "July";
                Month2 = "August";
                Month3 = "September";
            }
                    else if (drpQuarter.Text == "Fourth")
            {
            Month1 = "October";
                Month2 = "November";
                Month3 = "December";
            }

        string a = "";
        string qury = @" select  avg(AverageWeeklyRain)/90 As number From  ( 
	 SELECT isnull(tbl_NewRain.RainVal, 0) as AverageWeeklyRain
FROM tbl_NewRain
     
WHERE  tbl_NewRain.CityName = @City AND  [Month] in  ( @Month1, @Month2, @Month3) group by RainVal) a";
        SqlCommand cmd = new SqlCommand(qury, con);
        //cmd.Parameters.Add("@Month", SqlDbType.VarChar).Value = rmonth;
        cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = rdist;
        cmd.Parameters.Add("@Month1", SqlDbType.VarChar).Value = Month1;
        cmd.Parameters.Add("@Month2", SqlDbType.VarChar).Value = Month2;
        cmd.Parameters.Add("@Month3", SqlDbType.VarChar).Value = Month3;

      
        cmd.CommandType = CommandType.Text;
        decimal t = 0;
        try
            {
            con.Open();
            SqlDataReader me = cmd.ExecuteReader(CommandBehavior.SingleRow);
            if (me.Read())
                {
                if (me["number"] == DBNull.Value)
                    t = 0;
                else
                    t = decimal.Parse(me["number"].ToString());
                }

            con.Close();
            }
        catch (Exception ex)
            {
            throw ex;
            }
        finally
            {
            if (con.State == ConnectionState.Open)
                con.Close();
            }
        return t;
        }



    public int GetDistId(string DistName)
        {
       
        string qury = @"Select DistrictId From tblDist where DistName =@DistName";
        SqlCommand cmd = new SqlCommand(qury, con);
        cmd.Parameters.Add("@DistName", SqlDbType.VarChar).Value = DistName;
        cmd.CommandType = CommandType.Text;
        int t = 0;
        try
            {
            con.Open();
            SqlDataReader me = cmd.ExecuteReader(CommandBehavior.SingleRow);
            if (me.Read())
                {
                if (me["DistrictId"] == DBNull.Value)
                    t = 0;
                else
                    t = Convert.ToInt32(me["DistrictId"]);
                }

            con.Close();
            }
        catch (Exception ex)
            {
            throw ex;
            }
        finally
            {
            if (con.State == ConnectionState.Open)
                con.Close();
            }
        return t;
        }
    public DataSet GraphData(string ryear, string rdist)
        {
        int Between1 = 0;
        int Between2 =0;
        if (drpQuarter.Text == "First")
            {
            Between1 = 1;
            Between2 = 3;
            }
        else if (drpQuarter.Text == "Second")
            {
            Between1 = 4;
            Between2 = 6;
            }

        else if (drpQuarter.Text == "Third")
            {
            Between1 = 7;
            Between2 = 9;
            }
        else if (drpQuarter.Text == "Fourth")
            {
            Between1 = 10;
            Between2 = 12;
            }

        int distID = GetDistId(Session["username"].ToString());
                SqlCommand cmd = new SqlCommand();
        int Month = 0;


        cmd.CommandText = "Select  Sum(TotalVals) AS TotalVals , Sum(PredValues) AS PredValues, Sum(Total) As Total, MONTH(z.Date) AS Day from  (Select *,(TotalVals+Total) as PredValues from (SELECT convert (varchar(50),(convert(varchar(4),tbl_NewTemperature.Year) + '-' + tbl_NewTemperature.Month +'-' + convert(varchar(2),tbl_NewTemperature.Day))) AS Date,  [tbl_NewTemperature].Day, -134.0 + 3.32 *(isnull([tbl_NewTemperature].AverageTemp, 0)) + 0.077 *(isnull(tbl_NewRain.RainVal, 0)) + 1.697 * (isnull([tbl_NewHumidity].AverageHumidity, 0)) + isnull(tbl_NewRain.RainVal, 0) AS TotalVals FROM[tbl_NewTemperature] INNER JOIN[tbl_NewHumidity] ON[tbl_NewTemperature].TempId = [tbl_NewHumidity].HumidityId INNER JOIN tbl_NewRain ON tbl_NewRain.RainId = [tbl_NewTemperature].TempId WHERE[tbl_NewTemperature].CityName = @CityName )  A inner join(Select Count(RegNo) As Total, DistId, right(RegDate, 2) As Dayss, RegDate from tblRegistration group by RegDate, DistId having DistId = @DistID) B on  A.Date = b.RegDate ) Z Group By  MONTH(z.Date) having MONTH(z.Date) between @between1 and @between2";

        SqlDataAdapter da = new SqlDataAdapter();
       
        
        cmd.Parameters.Add("@CityName", SqlDbType.VarChar).Value = rdist;
        
        cmd.Parameters.Add("@DistID", SqlDbType.Int).Value = distID;
        cmd.Parameters.Add("@between1", SqlDbType.Int).Value = Between1;
        cmd.Parameters.Add("@between2", SqlDbType.Int).Value = Between2;

        DataSet ds = new DataSet();
        cmd.Connection = con;
        da.SelectCommand = cmd;
        da.Fill(ds);
        return ds;
}
    }