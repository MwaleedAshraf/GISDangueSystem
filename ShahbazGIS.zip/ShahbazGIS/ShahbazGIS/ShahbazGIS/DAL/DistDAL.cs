﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for DistDAL
/// </summary>
public class DistDAL
{
    SqlConnection con = new SqlConnection(DALHelper.ConnectionString);
    public DataTable GetDist(string name)
    {
        SqlCommand cmd = new SqlCommand("select * from tbldist where DistName="+name+"'", con);
        DataSet ds = new DataSet();
        DataTable tbl = new DataTable();
        
        SqlDataAdapter sqlDAdpt = new SqlDataAdapter(cmd);
        try
        {
            if (con.State == ConnectionState.Closed) con.Open();
            sqlDAdpt.Fill(ds, "GetData");
            if (ds.Tables["GetData"].Rows.Count > 0)
            {
                tbl = ds.Tables["GetData"];
            }
            else
                tbl = ds.Tables["GetData"];
        }
        catch
        {


        }
        finally
        {
            if (con.State == ConnectionState.Open) con.Close();
        }
        //if (ds != null) ds.TrimExcess();
        return tbl;
    }

    public int GetMaxPCode(string name)
    {
        string querry = "select DistrictId from tblDist where DistName='"+name+"'";
        SqlCommand cmd = new SqlCommand(querry, con);
        cmd.CommandType = CommandType.Text;
        int t = 0;
        try
        {
            con.Open();
            SqlDataReader me = cmd.ExecuteReader(CommandBehavior.SingleRow);
            if (me.Read())
            {
                if (me["DistrictId"] == DBNull.Value)
                    t = 0;
                else
                    t = Convert.ToInt32(me["DistrictId"]);
            }

            con.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
                con.Close();
        }
        return t;

    }

}