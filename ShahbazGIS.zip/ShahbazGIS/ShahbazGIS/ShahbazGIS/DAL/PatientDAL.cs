﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for PatientDAL
/// </summary>
public class PatientDAL
{
    SqlConnection con = new SqlConnection(DALHelper.ConnectionString);
    public void SavePatient(PatientBLL ur)
    {



        SqlCommand cmd = new SqlCommand("insert into tblRegistration (RegDate,SEX,Age,DistId,Status,LabResultIGM,LabResultIGG,weeks) values ('"+ur.RegDate+"','"+ur.SEX+"','"+ur.Age+"',"+ur.CityId+",'"+ur.Status+"','"+ur.LabResultIGM+"','"+ur.LabResultIGG+"','"+ur.week+"')", con);
        //cmd.CommandType = CommandType.Text;
        //cmd.Parameters.Add(new SqlParameter("@RegDate", ur.RegDate));
        //cmd.Parameters.Add(new SqlParameter("@SEX", ur.SEX));
        //cmd.Parameters.Add(new SqlParameter("@Age", ur.Age));
        //cmd.Parameters.Add(new SqlParameter("@DistId", ur.CityId));
        //cmd.Parameters.Add(new SqlParameter("@Status", ur.Status));
        //cmd.Parameters.Add(new SqlParameter("@LabResultIGM", ur.LabResultIGM));
        //cmd.Parameters.Add(new SqlParameter("@LabResultIGG", ur.LabResultIGG));
        try
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            cmd.ExecuteNonQuery();
        }
        catch
        {
        }
        finally
        {
            if (con.State == ConnectionState.Open)
                con.Close();
        }
    }

}