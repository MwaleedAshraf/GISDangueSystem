﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class Adminpage : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(DALHelper.ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            
        }
        else
        {
            int number;
            lblDistrictName.Text = Session["username"].ToString();
            number = GetDist(lblDistrictName.Text);
            lblNoofPatients.Text = number.ToString();
        }
            
    }
    public int GetDist(string name)
    {

        string a = "";
        string qury = @"select count(r.DistId) as number from tblRegistration r
join tblDist d on d.DistrictId=r.DistId
where d.DistName='" + name+"'";
        SqlCommand cmd = new SqlCommand(qury, con);
        cmd.CommandType = CommandType.Text;
        int t = 0;
        try
        {
            con.Open();
            SqlDataReader me = cmd.ExecuteReader(CommandBehavior.SingleRow);
            if (me.Read())
            {
                if (me["number"] == DBNull.Value)
                    t = 0;
                else
                    t = Convert.ToInt32(me["number"]);
            }

            con.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
                con.Close();
        }
        return t;
    }

}