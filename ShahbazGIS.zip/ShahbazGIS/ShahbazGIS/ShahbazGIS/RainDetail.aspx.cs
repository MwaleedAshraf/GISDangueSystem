﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class RainDetail : System.Web.UI.Page
    {

        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GridRain_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "GetsStatus")
            {
                Session["R_RainID"] = e.CommandArgument;
                Response.Redirect("Rain");

            }
            else if (e.CommandName == "DeleteStatus")
            {
                Session["R_RainID"] = e.CommandArgument;
                DeleteRain(Convert.ToInt32(Session["R_RainID"]));
                GridRain.DataBind();
            }
        }
        //Delete Experience

        public string DeleteRain(int R_RainID)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteRain";
            cmd.Parameters.Add("@RainID", SqlDbType.Int).Value = R_RainID;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }

        protected void GridRain_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}