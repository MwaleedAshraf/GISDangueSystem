﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Login : System.Web.UI.Page
{
    UserBLL l = new UserBLL();
    UserDAL uDAL = new UserDAL();
    string utype = "";
    string type;
    protected void Page_Load(object sender, EventArgs e)
    {
        txtUsername.Focus();
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string a;
        string str;
        
        if (this.txtUsername.Text == "")
        {
            lblMessage.Text = "First Enter Username";
            lblMessage.Visible = true;
        }
        else
        {
            a = this.txtUsername.Text;
            l.UserName = a;
            l.Password = this.txtpassword.Text;
            str = this.txtpassword.Text;
            l=uDAL.logon(l);
            if (a == "" || str == "")
            {
                lblMessage.Text = "Please Enter Complete record to login successfully";
                lblMessage.Visible = true;
            }
            else if (l.UserName == a && l.Password == str)
            {
                Session["username"] = txtUsername.Text;
                Response.Redirect("Adminpage.aspx");

            }
            else
            {
                lblMessage.Text = "Username or Password not match";
                lblMessage.Visible = true;
                txtUsername.Text = "";
                txtpassword.Text = "";
                txtUsername.Focus();
            }
        }
    }
}