﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class HumidityDetail : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void GridHumidity_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "GetsStatus")
            {
                Session["H_HumidityID"] = e.CommandArgument;
                Response.Redirect("Humidity");

            }
            else if (e.CommandName == "DeleteStatus")
            {
                Session["H_HumidityID"] = e.CommandArgument;
                DeleteHumidity(Convert.ToInt32(Session["H_HumidityID"]));
                GridHumidity.DataBind();
            }
        }
        //Delete Experience

        public string DeleteHumidity(int H_HumidityID)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteHumidity";
            cmd.Parameters.Add("@HumidityID", SqlDbType.Int).Value = H_HumidityID;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }

        protected void GridHumidity_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}