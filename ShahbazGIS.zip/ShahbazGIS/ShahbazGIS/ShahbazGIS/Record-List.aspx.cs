﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Record_List : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(DALHelper.ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    string month;
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (ddlMonth.Text == "January")
        {
            month = "1";
        }
        else if (ddlMonth.Text == "February")
        {
            month = "2";
        }
        else if (ddlMonth.Text == "March")
        {
            month = "3";
        }
        else if (ddlMonth.Text == "April")
        {
            month = "4";
        }
        else if (ddlMonth.Text == "May")
        {
            month = "5";
        }
        else if (ddlMonth.Text == "June")
        {
            month = "6";
        }
        else if (ddlMonth.Text == "July")
        {
            month = "7";
        }
        else if (ddlMonth.Text == "August")
        {
            month = "8";
        }
        else if (ddlMonth.Text == "September")
        {
            month = "9";
        }
        else if (ddlMonth.Text == "October")
        {
            month = "10";
        }
        else if (ddlMonth.Text == "November")
        {
            month = "11";
        }
        else if (ddlMonth.Text == "December")
        {
            month = "12";
        }
        else
        { }

        SqlDataAdapter Adp = new SqlDataAdapter(@"select d.DistName [District Name],COUNT(r.RegDate) as [No. of Patients] from tblRegistration r
left outer join tblDist d
on r.DistId=d.DistrictId where Month(r.RegDate)="+month+" and Year(r.RegDate)="+ddlYear.Text+" and Weeks='"+ddlWeeks.Text+"' group by d.DistName ", con);
        DataTable Dt = new DataTable();
        Adp.Fill(Dt);
        //GridView1.DataSource = Dt;
        //GridView1.DataBind();
        
    }
}