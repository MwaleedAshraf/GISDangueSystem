﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class RainNew : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindCity();
                Convert.ToInt32(Session["T_RainID"]);
                ViewNewRain(Convert.ToInt32(Session["T_RainID"]));
            }
        }
        public void BindCity()
        {
            DataSet ds = new DataSet();
            ds = GetCity();

            drpCity.DataTextField = "City";
            drpCity.DataSource = ds;
            drpCity.DataBind();

        }

        public DataSet GetCity()
        {

            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            DataSet ds = new DataSet();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct city from tblDailyRain order by city ";
            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            conn.Close();
            return ds;

        }
        public void ViewNewRain(int T_RainID)
        {
            try
            {
                conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
                SqlCommand cmd;
                string str;
                conn.Open();
                str = "select * from tbl_NewRain where RainId='" + T_RainID + "'";
                cmd = new SqlCommand(str, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    drpCity.Value = reader["CityName"].ToString();
                    drpYear.Value = reader["Year"].ToString();
                    drpDay.Value = reader["Day"].ToString();
                    drpMonth.Value = reader["Month"].ToString();
                    txtrainval.Value = reader["RainVal"].ToString();
                   

                    conn.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }
        }
        //Add New Rain
        public string AddNewRain(string CityName, int Year, int Day, string Month, decimal RainVal)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "AddNewRain ";
            cmd.Parameters.Add("@CityName", SqlDbType.VarChar).Value = CityName;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year;
            cmd.Parameters.Add("@Day", SqlDbType.Int).Value = Day;
            cmd.Parameters.Add("@Month", SqlDbType.VarChar).Value = Month;
            cmd.Parameters.Add("@RainVal", SqlDbType.Decimal).Value = RainVal;

            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btn_save_Click(object sender, EventArgs e)
        {

            string res = AddNewRain(drpCity.Value, int.Parse(drpYear.Value), int.Parse(drpDay.Value), drpMonth.Value, decimal.Parse(txtrainval.Value));
            lblMessage.Text = "Record Successfully Inserted";
        }
        public string UpdateNewRain(int RainId,string CityName, int Year, int Day, string Month, decimal RainVal)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "UpdateNewRain";
            cmd.Parameters.Add("@RainId", SqlDbType.Int).Value = RainId;
            cmd.Parameters.Add("@CityName", SqlDbType.VarChar).Value = CityName;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year;
            cmd.Parameters.Add("@Day", SqlDbType.Int).Value = Day;
            cmd.Parameters.Add("@Month", SqlDbType.VarChar).Value = Month;
            cmd.Parameters.Add("@RainVal", SqlDbType.Decimal).Value = RainVal;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            string res = UpdateNewRain(Convert.ToInt32(Session["T_RainID"]), drpCity.Value, int.Parse(drpYear.Value), int.Parse(drpDay.Value), drpMonth.Value, decimal.Parse(txtrainval.Value)).ToString();
            lblMessage.Text = "Record Successfully Updated";
            Response.Redirect("RainNewDetail");
        }

        //Delete Dayoff Method

        protected void btnDetail_Click(object sender, EventArgs e)
        {
            Response.Redirect("RainNewDetail");
        }
    }
}