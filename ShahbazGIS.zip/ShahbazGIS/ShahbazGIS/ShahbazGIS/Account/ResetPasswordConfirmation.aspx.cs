﻿using System.Web.UI;

namespace ShahbazGIS.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}