﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class HumidityAverageDetail : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void GridHumidityAverage_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "GetsStatus")
            {
                Session["T_HumidityAvgID"] = e.CommandArgument;
                Response.Redirect("HumidityAverage");

            }
            else if (e.CommandName == "DeleteStatus")
            {
                Session["T_HumidityAvgID"] = e.CommandArgument;
                DeleteHumidityAvg(Convert.ToInt32(Session["T_HumidityAvgID"]));
                GridHumidityAverage.DataBind();
            }
        }
        //Delete Experience

        public string DeleteHumidityAvg(int T_HumidityAvgID)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteAvgHumidity";
            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = T_HumidityAvgID;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }

        protected void GridHumidityAverage_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}