﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class WeeklyTemperature : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindCity();
                Convert.ToInt32(Session["H_WeeklyTempID"]);
                ViewWeeklyTemp(Convert.ToInt32(Session["H_WeeklyTempID"]));
            }
        }
        public void BindCity()
        {
            DataSet ds = new DataSet();
            ds = GetCity();

            drpCity.DataTextField = "City";
            drpCity.DataSource = ds;
            drpCity.DataBind();

        }

        public DataSet GetCity()
        {

            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            DataSet ds = new DataSet();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct city from tblWeeklyTemp order by city ";
            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            conn.Close();
            return ds;

        }
        public void ViewWeeklyTemp(int H_WeeklyTempID)
        {
            try
            {
                conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
                SqlCommand cmd;
                string str;
                conn.Open();
                str = "select * from tblWeeklyTemp where ID='" + H_WeeklyTempID + "'";
                cmd = new SqlCommand(str, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    drpCity.Value = reader["City"].ToString();
                    drpYear.Value = reader["Year"].ToString();
                    drpDay.Value = reader["Week"].ToString();
                    txtJan.Value = reader["Jan"].ToString();
                    txtFeb.Value = reader["Feb"].ToString();
                    txtMar.Value = reader["Mar"].ToString();
                    txtApril.Value = reader["April"].ToString();
                    txtMay.Value = reader["May"].ToString();
                    txtJune.Value = reader["June"].ToString();
                    txtJuly.Value = reader["July"].ToString();
                    txtAug.Value = reader["Aug"].ToString();
                    txtSep.Value = reader["Sep"].ToString();
                    txtOct.Value = reader["Oct"].ToString();
                    txtNov.Value = reader["Nov"].ToString();
                    txtDec.Value = reader["Dec"].ToString();

                    conn.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }
        }

        public string AddWeeklyTemp(string City, int Year, float Week, decimal Jan, decimal Feb, decimal Mar, decimal April, decimal May, decimal June, decimal July, decimal Aug, decimal Sep, decimal Oct, decimal Nov, decimal Dec)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "AddWeeklyTemp ";
            cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = City;
            cmd.Parameters.Add("@Yaer", SqlDbType.Int).Value = Year;
            cmd.Parameters.Add("@Week", SqlDbType.Float).Value = Week;
            cmd.Parameters.Add("@Jan", SqlDbType.Decimal).Value = Jan;
            cmd.Parameters.Add("@Feb", SqlDbType.Decimal).Value = Feb;
            cmd.Parameters.Add("@March", SqlDbType.Decimal).Value = Mar;
            cmd.Parameters.Add("@April", SqlDbType.Decimal).Value = April;
            cmd.Parameters.Add("@May", SqlDbType.Decimal).Value = May;
            cmd.Parameters.Add("@June", SqlDbType.Decimal).Value = June;
            cmd.Parameters.Add("@July", SqlDbType.Decimal).Value = July;
            cmd.Parameters.Add("@Aug", SqlDbType.Decimal).Value = Aug;
            cmd.Parameters.Add("@Sep", SqlDbType.Decimal).Value = Sep;
            cmd.Parameters.Add("@Oct", SqlDbType.Decimal).Value = Oct;
            cmd.Parameters.Add("@Nov", SqlDbType.Decimal).Value = Nov;
            cmd.Parameters.Add("@Dec", SqlDbType.Decimal).Value = Dec;

            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btn_save_Click(object sender, EventArgs e)
        {

            string res = AddWeeklyTemp(drpCity.Value, int.Parse(drpYear.Value), float.Parse(drpDay.Value), decimal.Parse(txtJan.Value), decimal.Parse(txtFeb.Value), decimal.Parse(txtMar.Value), decimal.Parse(txtApril.Value), decimal.Parse(txtMay.Value), decimal.Parse(txtJune.Value), decimal.Parse(txtJuly.Value), decimal.Parse(txtAug.Value), decimal.Parse(txtSep.Value), decimal.Parse(txtOct.Value), decimal.Parse(txtNov.Value), decimal.Parse(txtDec.Value));
            lblMessage.Text = "Record Successfully Inserted";
        }
        public string UpdateWeeklyTemp(int ID, string City, int Year, float Week, decimal Jan, decimal Feb, decimal Mar, decimal April, decimal May, decimal June, decimal July, decimal Aug, decimal Sep, decimal Oct, decimal Nov, decimal Dec)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "UpdateWeeklyTemp";
            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = ID;
            cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = City;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year;
            cmd.Parameters.Add("@Week", SqlDbType.Float).Value = Week;
            cmd.Parameters.Add("@Jan", SqlDbType.Decimal).Value = Jan;
            cmd.Parameters.Add("@Feb", SqlDbType.Decimal).Value = Feb;
            cmd.Parameters.Add("@March", SqlDbType.Decimal).Value = Mar;
            cmd.Parameters.Add("@April", SqlDbType.Decimal).Value = April;
            cmd.Parameters.Add("@May", SqlDbType.Decimal).Value = May;
            cmd.Parameters.Add("@June", SqlDbType.Decimal).Value = June;
            cmd.Parameters.Add("@July", SqlDbType.Decimal).Value = July;
            cmd.Parameters.Add("@Aug", SqlDbType.Decimal).Value = Aug;
            cmd.Parameters.Add("@Sep", SqlDbType.Decimal).Value = Sep;
            cmd.Parameters.Add("@Oct", SqlDbType.Decimal).Value = Oct;
            cmd.Parameters.Add("@Nov", SqlDbType.Decimal).Value = Nov;
            cmd.Parameters.Add("@Dec", SqlDbType.Decimal).Value = Dec;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            string res = UpdateWeeklyTemp(Convert.ToInt32(Session["H_WeeklyTempID"]),drpCity.Value, int.Parse(drpYear.Value), float.Parse(drpDay.Value), decimal.Parse(txtJan.Value), decimal.Parse(txtFeb.Value), decimal.Parse(txtMar.Value), decimal.Parse(txtApril.Value), decimal.Parse(txtMay.Value), decimal.Parse(txtJune.Value), decimal.Parse(txtJuly.Value), decimal.Parse(txtAug.Value), decimal.Parse(txtSep.Value), decimal.Parse(txtOct.Value), decimal.Parse(txtNov.Value), decimal.Parse(txtDec.Value)).ToString();
            lblMessage.Text = "Record Successfully Updated";
            Response.Redirect("WeeklyTemperatureDetail");
        }

        //Delete Dayoff Method

        protected void btnDetail_Click(object sender, EventArgs e)
        {
            Response.Redirect("WeeklyTemperatureDetail");
        }

    }
}