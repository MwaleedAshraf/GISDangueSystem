﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Change_Password : System.Web.UI.Page
{
    UserBLL u = new UserBLL();
    UserDAL uDAL = new UserDAL();
    bool pflag = false;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        pflag = uDAL.passexist(Session["username"].ToString(),txtOldPassword.Text);
        if (pflag == true)
        {
            if (txtnewpassword.Text == txtrenewPassword.Text)
            {
                u.UserName = Session["username"].ToString();
                u.Password = txtnewpassword.Text;
                uDAL.updateuser(u);
                lblMessage.Text = "Password Changed Successfully";
                lblMessage.Visible = true;
            }
            else
            {
                lblMessage.Text = "Password Not Match";
                lblMessage.Visible = true;
                return;
            }
        }
        else
        {
            lblMessage.Text = "Incorrect old Password";
            lblMessage.Visible = true;
            txtOldPassword.Focus();
            return;
        }
    }
}