﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserBLL
/// </summary>
public class UserBLL
{
    private int _userID;

    public int UserID
    {
        get { return _userID; }
        set { _userID = value; }
    }

    private string _userName;

    public string UserName
    {
        get { return _userName; }
        set { _userName = value; }
    }

    private string _password;

    public string Password
    {
        get { return _password; }
        set { _password = value; }
    }

    private string _type;

    public string Type
    {
        get { return _type; }
        set { _type = value; }
    }

    private string _status;

    public string Status
    {
        get { return _status; }
        set { _status = value; }
    }

    private string _transDate;

    public string TransDate
    {
        get { return _transDate; }
        set { _transDate = value; }
    }
}