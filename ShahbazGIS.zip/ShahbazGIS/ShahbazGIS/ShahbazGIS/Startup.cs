﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ShahbazGIS.Startup))]
namespace ShahbazGIS
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
