﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class HumidityNew : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindCity();
                Convert.ToInt32(Session["T_HumidityID"]);
                ViewNewHumidity(Convert.ToInt32(Session["T_HumidityID"]));
            }
        }
        public void BindCity()
        {
            DataSet ds = new DataSet();
            ds = GetCity();

            drpCity.DataTextField = "City";
            drpCity.DataSource = ds;
            drpCity.DataBind();

        }

        public DataSet GetCity()
        {

            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            DataSet ds = new DataSet();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct city from tblDailyRain order by city ";
            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            conn.Close();
            return ds;

        }
        public void ViewNewHumidity(int T_HumidityID)
        {
            try
            {
                conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
                SqlCommand cmd;
                string str;
                conn.Open();
                str = "select * from tbl_NewHumidity where HumidityId='" + T_HumidityID + "'";
                cmd = new SqlCommand(str, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    drpCity.Value = reader["CityName"].ToString();
                    drpYear.Value = reader["Year"].ToString();
                    drpDay.Value = reader["Day"].ToString();
                    drpMonth.Value = reader["Month"].ToString();
                    txtmorningval.Value = reader["Morning_Humidity"].ToString();
                    txteveningval.Value = reader["Evening_Humidity"].ToString();
                    txtAvgval.Value = reader["AverageHumidity"].ToString();


                    conn.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }
        }
        //Add New Rain
        public string AddNewHumidity(string CityName, int Year, int Day, string Month, float Morning_Humidity, float Evening_Humidity,float AverageHumidity)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "AddNewHumidity ";
            cmd.Parameters.Add("@CityName", SqlDbType.VarChar).Value = CityName;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year;
            cmd.Parameters.Add("@Day", SqlDbType.Int).Value = Day;
            cmd.Parameters.Add("@Month", SqlDbType.VarChar).Value = Month;
            cmd.Parameters.Add("@Morning_Humidity", SqlDbType.Float).Value = Morning_Humidity;
            cmd.Parameters.Add("@Evening_Humidity", SqlDbType.Float).Value = Evening_Humidity;
            cmd.Parameters.Add("@AverageHumidity", SqlDbType.Float).Value = AverageHumidity;

            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btn_save_Click(object sender, EventArgs e)
        {

            string res = AddNewHumidity(drpCity.Value, int.Parse(drpYear.Value), int.Parse(drpDay.Value), drpMonth.Value, float.Parse(txtmorningval.Value), float.Parse(txteveningval.Value), float.Parse(txtAvgval.Value));
            lblMessage.Text = "Record Successfully Inserted";
        }
        public string UpdateNewHumidity(int HumidityId, string CityName, int Year, int Day, string Month, float Morning_Humidity, float Evening_Humidity, float AverageHumidity)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "UpdateNewHumidity";
            cmd.Parameters.Add("@HumidityId", SqlDbType.VarChar).Value = HumidityId;
            cmd.Parameters.Add("@CityName", SqlDbType.VarChar).Value = CityName;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year;
            cmd.Parameters.Add("@Day", SqlDbType.Int).Value = Day;
            cmd.Parameters.Add("@Month", SqlDbType.VarChar).Value = Month;
            cmd.Parameters.Add("@Morning_Humidity", SqlDbType.Float).Value = Morning_Humidity;
            cmd.Parameters.Add("@Evening_Humidity", SqlDbType.Float).Value = Evening_Humidity;
            cmd.Parameters.Add("@AverageHumidity", SqlDbType.Float).Value = AverageHumidity;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            string res = UpdateNewHumidity(Convert.ToInt32(Session["T_HumidityID"]), drpCity.Value, int.Parse(drpYear.Value), int.Parse(drpDay.Value), drpMonth.Value, float.Parse(txtmorningval.Value), float.Parse(txteveningval.Value), float.Parse(txtAvgval.Value)).ToString();
            lblMessage.Text = "Record Successfully Updated";
            Response.Redirect("RainNewDetail");
        }

        //Delete Dayoff Method

        protected void btnDetail_Click(object sender, EventArgs e)
        {
            Response.Redirect("HumidityNewDetail");
        }
    }
}