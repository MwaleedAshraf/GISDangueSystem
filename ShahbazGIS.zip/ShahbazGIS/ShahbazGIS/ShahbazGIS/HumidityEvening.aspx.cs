﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class HumidityEvening : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindCity();
                Convert.ToInt32(Session["T_HumidityEveID"]);
                ViewTemperature(Convert.ToInt32(Session["T_HumidityEveID"]));
            }
        }
        public void BindCity()
        {
            DataSet ds = new DataSet();
            ds = GetCity();

            drpCity.DataTextField = "City";
            drpCity.DataSource = ds;
            drpCity.DataBind();

        }

        public DataSet GetCity()
        {

            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            DataSet ds = new DataSet();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct city from tblMinTemp order by city ";
            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            conn.Close();
            return ds;

        }
        public void ViewTemperature(int T_HumidityEveID)
        {
            try
            {
                conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
                SqlCommand cmd;
                string str;
                conn.Open();
                str = "select * from tblHumidityEvening where ID='" + T_HumidityEveID + "'";
                cmd = new SqlCommand(str, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    drpCity.Value = reader["City"].ToString();
                    drpYear.Value = reader["Year"].ToString();
                    drpDay.Value = reader["Date"].ToString();
                    txtJan.Value = reader["Jan"].ToString();
                    txtFeb.Value = reader["Feb"].ToString();
                    txtMar.Value = reader["March"].ToString();
                    txtApril.Value = reader["April"].ToString();
                    txtMay.Value = reader["May"].ToString();
                    txtJune.Value = reader["June"].ToString();
                    txtJuly.Value = reader["July"].ToString();
                    txtAug.Value = reader["Aug"].ToString();
                    txtSep.Value = reader["Sep"].ToString();
                    txtOct.Value = reader["Oct"].ToString();
                    txtNov.Value = reader["Nov"].ToString();
                    txtDec.Value = reader["Dec"].ToString();

                    conn.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }
        }

        public string AddMinTemperature(string City,int Year, float Date, float Jan, float Feb, float Mar, float April, float May, float June, float July, float Aug, float Sep, float Oct, float Nov, float Dec)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "AddEveningHumidity ";
            cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = City;
            cmd.Parameters.Add("@Year", SqlDbType.VarChar).Value = Year;
            cmd.Parameters.Add("@Date", SqlDbType.Float).Value = Date;
            cmd.Parameters.Add("@Jan", SqlDbType.Float).Value = Jan;
            cmd.Parameters.Add("@Feb", SqlDbType.Float).Value = Feb;
            cmd.Parameters.Add("@March", SqlDbType.Float).Value = Mar;
            cmd.Parameters.Add("@April", SqlDbType.Float).Value = April;
            cmd.Parameters.Add("@May", SqlDbType.Float).Value = May;
            cmd.Parameters.Add("@June", SqlDbType.Float).Value = June;
            cmd.Parameters.Add("@July", SqlDbType.Float).Value = July;
            cmd.Parameters.Add("@Aug", SqlDbType.Float).Value = Aug;
            cmd.Parameters.Add("@Sep", SqlDbType.Float).Value = Sep;
            cmd.Parameters.Add("@Oct", SqlDbType.Float).Value = Oct;
            cmd.Parameters.Add("@Nov", SqlDbType.Float).Value = Nov;
            cmd.Parameters.Add("@Dec", SqlDbType.Float).Value = Dec;

            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btn_save_Click(object sender, EventArgs e)
        {

            string res = AddMinTemperature(drpCity.Value,int.Parse(drpYear.Value), float.Parse(drpDay.Value), float.Parse(txtJan.Value), float.Parse(txtFeb.Value), float.Parse(txtMar.Value), float.Parse(txtApril.Value), float.Parse(txtMay.Value), float.Parse(txtJune.Value), float.Parse(txtJuly.Value), float.Parse(txtAug.Value), float.Parse(txtSep.Value), float.Parse(txtOct.Value), float.Parse(txtNov.Value), float.Parse(txtDec.Value));
            lblMessage.Text = "Record Successfully Inserted";
        }
        public string UpdateEveningHumidity(int ID, string City, int Year, float Date, float Jan, float Feb, float Mar, float April, float May, float June, float July, float Aug, float Sep, float Oct, float Nov, float Dec)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "UpdateEveHumidity";
            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = ID;
            cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = City;
            cmd.Parameters.Add("@Year", SqlDbType.Int).Value = Year;
            cmd.Parameters.Add("@Date", SqlDbType.Float).Value = Date;
            cmd.Parameters.Add("@Jan", SqlDbType.Float).Value = Jan;
            cmd.Parameters.Add("@Feb", SqlDbType.Float).Value = Feb;
            cmd.Parameters.Add("@March", SqlDbType.Float).Value = Mar;
            cmd.Parameters.Add("@April", SqlDbType.Float).Value = April;
            cmd.Parameters.Add("@May", SqlDbType.Float).Value = May;
            cmd.Parameters.Add("@June", SqlDbType.Float).Value = June;
            cmd.Parameters.Add("@July", SqlDbType.Float).Value = July;
            cmd.Parameters.Add("@Aug", SqlDbType.Float).Value = Aug;
            cmd.Parameters.Add("@Sep", SqlDbType.Float).Value = Sep;
            cmd.Parameters.Add("@Oct", SqlDbType.Float).Value = Oct;
            cmd.Parameters.Add("@Nov", SqlDbType.Float).Value = Nov;
            cmd.Parameters.Add("@Dec", SqlDbType.Float).Value = Dec;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }
        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            string res = UpdateEveningHumidity(Convert.ToInt32(Session["T_HumidityEveID"]), drpCity.Value, int.Parse(drpYear.Value), float.Parse(drpDay.Value), float.Parse(txtJan.Value), float.Parse(txtFeb.Value), float.Parse(txtMar.Value), float.Parse(txtApril.Value), float.Parse(txtMay.Value), float.Parse(txtJune.Value), float.Parse(txtJuly.Value), float.Parse(txtAug.Value), float.Parse(txtSep.Value), float.Parse(txtOct.Value), float.Parse(txtNov.Value), float.Parse(txtDec.Value)).ToString();
            lblMessage.Text = "Record Successfully Updated";
            Response.Redirect("HumidityEveningDetail");
        }

        //Delete Dayoff Method

        protected void btnDetail_Click(object sender, EventArgs e)
        {
            Response.Redirect("HumidityEveningDetail");
        }
    }
}