﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ShahbazGIS
{
    public partial class AverageTemperatureDetail : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void GridTemperature_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "GetsStatus")
            {
                Session["T_AVGTempID"] = e.CommandArgument;
                Response.Redirect("AverageTemperature");

            }
            else if (e.CommandName == "DeleteStatus")
            {
                Session["T_AVGTempID"] = e.CommandArgument;
                DeleteTemperature(Convert.ToInt32(Session["T_AVGTempID"]));
                GridTemperature.DataBind();
            }
        }
        //Delete Experience

        public string DeleteTemperature(int T_AVGTempID)
        {
            conn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GISDengueConnectionString"].ToString();
            conn.Open();
            cmd.Connection = conn;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteAvgTemp";
            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = T_AVGTempID;

            int i = cmd.ExecuteNonQuery();


            conn.Close();
            if (i > 0)
            {
                return "Success";
            }
            else { return "Fail"; }


        }

        protected void GridTemperature_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}